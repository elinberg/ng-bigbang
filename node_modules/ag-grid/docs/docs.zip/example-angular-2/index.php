<?php
$key = "Angular 2";
$pageTitle = "Angular 2 Data Grid";
$pageDescription = "This page describes how to use ag-grid with Angular 2.";
$pageKeyboards = "AngularJS Angular 2 Data Grid";
include '../documentation_header.php';
?>

<div>

    <h2>Angular 2</h2>

    <a href="/best-angularjs-2-grid/index.php">The example has moved to this page.</a>

</div>

<?php include '../documentation_footer.php';?>
