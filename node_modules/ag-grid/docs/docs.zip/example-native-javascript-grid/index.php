<?php
$key = "Native Javascript";
$pageTitle = "HTML 5 Grid without Angular JS";
$pageDescription = "How to use Angular Grid to create an HTML 5 grid without using AngularJS";
$pageKeyboards = "HTML 5 Javascript grid without AngularJS";
include '../documentation_header.php';
?>

<div>

    <h2>Native Javascript</h2>

    <a href="/best-javascript-grid/index.php">The example has moved to this page.</a>

</div>

<?php include '../documentation_footer.php';?>
