<?php
$key = "Angular Compiling";
$pageTitle = "AngularJS Data Grid - Angular Compiling";
$pageDescription = "Documentation on how to Angular Compile for Angular AngularJS Data Grid";
$pageKeyboards = "AngularJS Angular Data Grid Angular Compiling";
include '../documentation_header.php';
?>

<div>
    <h2>Angular Compiling</h2>

    <p>
        This page no longer exists.
    </p>
</div>

<?php include '../documentation_footer.php';?>
