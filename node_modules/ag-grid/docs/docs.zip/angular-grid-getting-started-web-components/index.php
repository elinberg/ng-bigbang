<?php
$key = "Getting Started Web Components";
$pageTitle = "Getting Started Web Components";
$pageDescription = "Getting Started Web Components";
$pageKeyboards = "Getting Started Web Components";
include '../documentation_header.php';
?>

<div>

    <h2>Getting Started - Web Components</h2>

    <p>
        This page will come soon...
    </p>

    <p>
        In the meantime, check out the <a href="/example-web-component-grid/index.php">Web Components Example</a>
    </p>

</div>

<?php include '../documentation_footer.php';?>
